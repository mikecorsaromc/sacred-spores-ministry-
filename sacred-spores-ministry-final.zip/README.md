# Sacred Spores Ministry - Next.js Site

This repository contains the Next.js + Tailwind prototype for Sacred Spores Ministry.

To run locally:
1. npm install
2. npm run dev
