import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Farm() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="logo-centered">
          <img src="/logo-256.png" alt="Sacred Spores Logo" className="w-36 h-36" />
          <h1 className="text-3xl font-bold text-center">The Farm</h1>
        </div>

        <p className="mt-4 text-gray-700">Our regenerative farm uses retrofitted refrigerated trailers to create controlled environments for gourmet and medicinal mushroom cultivation. Each harvest is approached as a ceremony of reciprocity.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-xl p-6 bg-white/80 border">
            <h3 className="font-semibold">King Trumpet</h3>
            <p className="mt-2 text-gray-700">Earthy, meaty, and chef-friendly. Grown with sustainable substrate and mindful hands.</p>
            <div className="mt-3 text-sm text-gray-500">Harvest cycle: 4–8 weeks</div>
          </div>
          <div className="rounded-xl p-6 bg-white/80 border">
            <h3 className="font-semibold">Lion's Mane</h3>
            <p className="mt-2 text-gray-700">Cognitive-supporting mushroom, celebrated for its unique texture and health benefits.</p>
            <div className="mt-3 text-sm text-gray-500">Harvest cycle: 3–6 weeks</div>
          </div>
        </div>

        <div className="mt-6 bg-white/60 p-6 rounded-lg border">
          <h4 className="font-semibold">Workshops & Tours</h4>
          <p className="mt-2 text-gray-700">We host monthly workshops covering inoculation, substrate prep, and mycoremediation — and ceremonial harvest days. Join the newsletter for dates.</p>
        </div>

        <Footer />
      </main>
    </div>
  )
}
