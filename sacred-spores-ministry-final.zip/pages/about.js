import Header from '../components/Header'
import Footer from '../components/Footer'
import Link from 'next/link'

export default function About() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="logo-centered">
          <img src="/logo-256.png" alt="Sacred Spores Logo" className="w-36 h-36" />
          <h1 className="text-3xl font-bold text-center">About Sacred Spores Ministry</h1>
        </div>

        <p className="mt-4 text-gray-700">The Ministry is founded to foster spiritual growth, community service, and ethical living. We operate a sustainable mushroom farm cultivating King Trumpet and Lion's Mane mushrooms, and we promote environmental stewardship, education, and local food security.</p>

        <section className="mt-8 bg-white/60 p-6 rounded-lg border">
          <h2 className="font-semibold">13 Guiding Principles</h2>
          <ul className="mt-3 list-disc pl-6 text-gray-700 space-y-2">
<li>Interconnectedness: We recognize the intrinsic unity of all living beings and the natural world, honoring the sacred web of life that binds us together.</li>
<li>Respect for Gaia: We reverence the Earth as our Mother, nurturing her ecosystems and preserving biodiversity, acknowledging our responsibility as stewards of the land.</li>
<li>Sovereignty: We empower individuals to take ownership of their spiritual journey, embracing their unique path and inner wisdom.</li>
<li>Pursuit of Truth: We seek knowledge and understanding through an open-hearted exploration of various wisdom traditions, sciences, and philosophies.</li>
<li>Love and Compassion: We cultivate empathy, kindness, and compassion towards all beings, recognizing the divine spark within each individual.</li>
<li>Enlightenment: We strive for spiritual growth, self-awareness, and higher consciousness, embracing the journey of awakening.</li>
<li>Non-Duality: We acknowledge the ultimate reality beyond duality, recognizing the unity and interconnectedness of all existence.</li>
<li>Stewardship: We manage the Sacred Spores Ministry's resources, including the land and its bounty, with mindfulness and sustainability.</li>
<li>Inclusivity: We welcome individuals from diverse backgrounds, honoring the unique experiences and perspectives each person brings.</li>
<li>Community: We foster a sense of belonging and cooperation, supporting one another on our individual and collective journeys.</li>
<li>Conscious Evolution: We recognize the potential for growth and transformation, embracing the evolution of human consciousness and the natural world.</li>
<li>Gratitude and Reciprocity: We express gratitude for the gifts of the Earth and our community, offering thanks and reciprocity in our actions.</li>
<li>Embodiment: We honor the sacredness of the human form, nurturing our physical, emotional, and spiritual well-being, and recognizing the divine spark within ourselves and others.</li>
          </ul>
        </section>

        <div className="mt-6">
          <Link href="/statement-of-faith"><a className="inline-block px-5 py-3 bg-ssGreen text-white rounded-lg">Read Statement of Faith</a></Link>
        </div>

        <Footer />
      </main>
    </div>
  )
}
