import Header from '../components/Header'
import Footer from '../components/Footer'
import NewsletterForm from '../components/NewsletterForm'
import DonationForm from '../components/DonationForm'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 via-white to-amber-50 text-gray-900">
      <Header />
      <main className="max-w-6xl mx-auto px-6 py-12">
        <section className="rounded-3xl p-8 shadow-xl bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-emerald-50 via-white to-amber-50">
          <div className="logo-centered">
            <img src="/logo-512.png" alt="Sacred Spores Logo" className="w-48 h-48" />
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight text-center">We are a ministry rooted in Earth and Spirit</h1>
            <p className="mt-4 text-lg text-gray-700 text-center">Cultivating mushrooms, consciousness, and community — guided by devotion to the living Earth and the practice of stewardship.</p>
            <div className="mt-6 flex gap-4">
              <Link href="/about"><a className="inline-block px-6 py-3 rounded-full bg-ssGreen text-white font-semibold">Learn More</a></Link>
              <Link href="/support"><a className="inline-block px-6 py-3 rounded-full border font-semibold">Support Our Work</a></Link>
            </div>
          </div>
        </section>

        <div className="mt-16 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="card">
            <h3 className="font-semibold">Mission</h3>
            <p className="mt-2 text-gray-700">We are a ministry rooted in Earth and Spirit — cultivating mushrooms, consciousness, and community.</p>
          </div>
          <div className="card">
            <h3 className="font-semibold">Vision</h3>
            <p className="mt-2 text-gray-700">To co-create a regenerative future where spiritual practice and sustainable agriculture restore the web of life.</p>
          </div>
          <div className="card">
            <h3 className="font-semibold">Join</h3>
            <p className="mt-2 text-gray-700">Become a member, volunteer at the farm, or attend our workshops — all are welcome.</p>
          </div>
        </div>

        <section className="mt-12 bg-white/60 rounded-2xl p-8 shadow-md">
          <h2 className="text-2xl font-bold">About Sacred Spores Ministry</h2>
          <p className="mt-4 text-gray-700">Sacred Spores Ministry blends spiritual practice with sustainable mycology. We cultivate King Trumpet and Lion's Mane mushrooms as acts of stewardship and service to the Earth.</p>
          <div className="mt-6">
            <Link href="/about"><a className="inline-block px-5 py-3 bg-ssGreen text-white rounded-lg font-semibold">Read Charter & Guiding Principles</a></Link>
          </div>
        </section>

        <section className="mt-12 rounded-2xl p-8 bg-gradient-to-r from-emerald-50 to-amber-50 shadow-lg">
          <h2 className="text-2xl font-bold">Support the Ministry</h2>
          <p className="mt-3 text-gray-700">Your financial support ensures the longevity of our programs, farm operations, and community outreach.</p>

          <div className="mt-6 flex flex-col md:flex-row gap-4 items-start">
            <div className="flex-1 card">
              <DonationForm />
            </div>
            <div className="w-full md:w-72 p-4 bg-white rounded-lg border">
              <h3 className="font-semibold">Transparency</h3>
              <p className="mt-2 text-sm text-gray-600">Annual financial reports available to donors. We commit to stewardship and responsible use of funds.</p>
            </div>
          </div>
        </section>

        <div className="mt-12">
          <NewsletterForm />
        </div>

        <Footer />
      </main>
    </div>
  )
}
