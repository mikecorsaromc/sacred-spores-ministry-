import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Contact() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="logo-centered">
          <img src="/logo-256.png" alt="Sacred Spores Logo" className="w-36 h-36" />
          <h1 className="text-3xl font-bold text-center">Contact Sacred Spores Ministry</h1>
        </div>

        <section className="mt-6 bg-white/60 p-6 rounded-lg border">
          <h2 className="font-semibold">Send us a message</h2>
          <form onSubmit={(e)=>{ e.preventDefault(); alert('Message sent (placeholder).'); }} className="mt-4 space-y-3">
            <input className="w-full rounded-lg border px-3 py-2" placeholder="Your name" />
            <input className="w-full rounded-lg border px-3 py-2" placeholder="you@domain.org" />
            <textarea className="w-full rounded-lg border px-3 py-2" rows="6" placeholder="Message"></textarea>
            <div className="flex gap-3">
              <button className="px-4 py-2 rounded-full bg-ssGreen text-white">Send</button>
              <button type="reset" className="px-4 py-2 rounded-full border">Reset</button>
            </div>
          </form>

          <div className="mt-6">
            <h3 className="font-semibold">Contact Info</h3>
            <p className="mt-2 text-gray-700">Sacred Spores Ministry — Lompoc, California<br/>Email: info@sacredspores.org</p>
          </div>
        </section>

        <Footer />
      </main>
    </div>
  )
}
