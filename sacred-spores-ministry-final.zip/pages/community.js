import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Community() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="logo-centered">
          <img src="/logo-256.png" alt="Sacred Spores Logo" className="w-36 h-36" />
          <h1 className="text-3xl font-bold text-center">Community & Service</h1>
        </div>

        <p className="mt-4 text-gray-700">We share harvests with local food banks, host educational programs, and offer ceremonial gatherings. Members and volunteers are the heart of our work.</p>

        <ul className="mt-6 list-disc pl-6 text-gray-700 space-y-2">
          <li>Volunteer days: monthly harvest and inoculation sessions.</li>
          <li>Teachings: monthly talks and the Living Codex blog.</li>
          <li>Outreach: donations to local food systems and educational scholarships.</li>
        </ul>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-xl p-6 bg-emerald-50 border">
            <h4 className="font-semibold">Become a Member</h4>
            <p className="mt-2 text-gray-700">Sign up to receive member updates and volunteer opportunities.</p>
          </div>
          <div className="rounded-xl p-6 bg-emerald-50 border">
            <h4 className="font-semibold">Volunteer</h4>
            <p className="mt-2 text-gray-700">Join a volunteer day — help inoculate, harvest, and package while learning the sacred methods.</p>
          </div>
        </div>

        <Footer />
      </main>
    </div>
  )
}
