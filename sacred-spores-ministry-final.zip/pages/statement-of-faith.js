import Header from '../components/Header'
import Footer from '../components/Footer'

export default function StatementOfFaith() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="logo-centered">
          <img src="/logo-256.png" alt="Sacred Spores Logo" className="w-36 h-36" />
          <h1 className="text-3xl font-bold text-center">Statement of Faith</h1>
        </div>

        <section className="mt-6 bg-white/60 p-6 rounded-lg border">
          <h2 className="font-semibold">Preamble</h2>
          <p className="mt-2 text-gray-700">We, the members and stewards of the Sacred Spores Ministry, affirm our devotion to the Divine Intelligence that animates all life. We recognize the sacred unity of the Earth and its inhabitants — the seen and unseen, the soil and spirit — as expressions of one living consciousness.</p>

          <h3 className="mt-4 font-semibold">Articles</h3>
          <div className="mt-2 text-gray-700 whitespace-pre-line">
Preamble\nWe, the members and stewards of the Sacred Spores Ministry, affirm our devotion to the Divine Intelligence that animates all life.\nWe recognize the sacred unity of the Earth and its inhabitants — the seen and unseen, the soil and spirit — as expressions of one living consciousness.\nThe Sacred Spores Ministry exists to honor, preserve, and evolve this consciousness through acts of cultivation, compassion, and conscious stewardship.\n\nArticle I — The Living Presence\nWe believe that Divine Presence flows through all creation — in the mycelial threads beneath our feet, in the air we breathe, and within every human heart.\nThis Presence is known by many names and forms across cultures; we acknowledge all paths that seek truth, harmony, and love.\n\nArticle II — The Earth as Sacred Body\nWe honor the Earth, whom we call Gaia, as the living temple of the Divine.\nThrough the nurturing of soil and the cultivation of mushrooms, we practice reverence, sustainability, and reciprocity — tending to the health of the planet as a sacred duty.\n\nArticle III — The Human as Seed and Steward\nWe affirm that every individual carries a divine spark — a sacred seed — capable of growth, illumination, and service.\nOur ministry seeks to guide individuals in awakening to their sovereignty, wisdom, and interconnection with all beings.\n\nArticle IV — The Path of Love and Compassion\nWe follow the universal law of Love, expressed as compassion, forgiveness, and unity.\nThrough service, education, and community, we embody love in action, cultivating peace within ourselves and our environment.\n\nArticle V — The Principle of Non-Duality\nWe recognize that all opposites are reconciled in the Divine — light and shadow, life and death, spirit and matter.\nWe honor this mystery as the sacred dance of creation, where all distinctions ultimately resolve into One.\n\nArticle VI — The Way of Stewardship\nWe believe that to care for the Earth and her creatures is to serve the Divine.\nThe cultivation of mushrooms and other life forms is both a spiritual act and a practical offering — a sacrament of renewal, balance, and nourishment.\n\nArticle VII — The Communion of Community\nWe affirm that community is the vessel of awakening.\nThrough fellowship, education, and the sharing of food and wisdom, we grow together in spirit.\nEach person’s gifts contribute to the whole, forming a web of mutual upliftment.\n\nArticle VIII — The Journey of Conscious Evolution\nWe believe humanity is in an era of awakening — a conscious evolution guided by love, knowledge, and integration with nature.\nThe Sacred Spores Ministry serves as a beacon for this evolution, nurturing both personal transformation and planetary healing.\n\nArticle IX — The Practice of Gratitude and Reciprocity\nWe live in continual gratitude for the blessings of existence.\nEvery harvest, every breath, and every relationship is sacred.\nIn gratitude, we give back — to the Earth, to each other, and to the Source of all creation.\n\nArticle X — The Embodiment of Spirit\nWe honor the body as a divine vessel.\nThrough mindful living, nourishment, and creative expression, we integrate spirit and form — realizing the unity of heaven and earth within ourselves.\n\nClosing Affirmation\n"As the spores give rise to the mycelial web, so do we awaken the divine network of life.\nThrough love, truth, and service, we grow — ever united, ever renewed, ever one."\n
          </div>
        </section>

        <Footer />
      </main>
    </div>
  )
}
