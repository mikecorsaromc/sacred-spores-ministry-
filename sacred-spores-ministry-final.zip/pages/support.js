import Header from '../components/Header'
import Footer from '../components/Footer'
import DonationForm from '../components/DonationForm'

export default function Support() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="logo-centered">
          <img src="/logo-256.png" alt="Sacred Spores Logo" className="w-36 h-36" />
          <h1 className="text-3xl font-bold text-center">Support the Ministry</h1>
        </div>

        <p className="mt-4 text-gray-700">Your support sustains our programs, farms, and community outreach. Donations go to farm upkeep, workshops, and donations to local food systems.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-4 bg-white rounded-lg border">
            <DonationForm />
          </div>
          <div className="p-4 bg-white rounded-lg border">
            <h4 className="font-semibold">How funds are used</h4>
            <ul className="mt-3 list-disc pl-6 text-gray-700">
              <li>Farm operations and substrate supplies</li>
              <li>Volunteer support and workshops</li>
              <li>Community donations and food bank contributions</li>
            </ul>
            <p className="mt-4 text-sm text-gray-600">Annual reports will be available to donors.</p>
          </div>
        </div>

        <Footer />
      </main>
    </div>
  )
}
