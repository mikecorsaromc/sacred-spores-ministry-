export default function DonationForm() {
  return (
    <form onSubmit={(e)=>{ e.preventDefault(); alert('Donation placeholder — Stripe integration can be enabled later.'); }} className="space-y-4">
      <label className="block">
        <span className="text-sm font-medium">Donation amount</span>
        <div className="mt-2 flex gap-2">
          <input type="number" min="1" defaultValue={25} className="w-full rounded-lg border px-3 py-2" />
          <select className="rounded-lg border px-3 py-2">
            <option>One-time</option>
            <option>Monthly</option>
          </select>
        </div>
      </label>
      <label className="block">
        <span className="text-sm font-medium">Email (for receipt)</span>
        <input type="email" placeholder="you@domain.org" className="mt-2 w-full rounded-lg border px-3 py-2" />
      </label>
      <div className="flex gap-3">
        <button type="submit" className="px-5 py-2 rounded-full bg-ssGreen text-white font-semibold">Donate</button>
        <a href="/support" className="px-5 py-2 rounded-full border">Learn about stewardship</a>
      </div>
    </form>
  )
}
