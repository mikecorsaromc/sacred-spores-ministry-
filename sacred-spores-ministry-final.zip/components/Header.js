import Link from 'next/link'

export default function Header(){ 
  return (
    <header className="sticky top-0 z-40 bg-white/70 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src="/logo-256.png" alt="Sacred Spores Logo" className="w-12 h-12 rounded-full" />
          <div>
            <div className="font-bold">Sacred Spores Ministry</div>
            <div className="text-xs text-gray-600">Cultivation · Community · Consciousness</div>
          </div>
        </div>
        <nav className="hidden md:flex gap-6 items-center text-sm font-medium">
          <Link href="/"><a className="hover:text-ssGreen">Home</a></Link>
          <Link href="/about"><a className="hover:text-ssGreen">About</a></Link>
          <Link href="/farm"><a className="hover:text-ssGreen">Farm</a></Link>
          <Link href="/community"><a className="hover:text-ssGreen">Community</a></Link>
          <Link href="/support"><a className="hover:text-ssGreen">Support</a></Link>
          <Link href="/contact"><a className="hover:text-ssGreen">Contact</a></Link>
        </nav>
      </div>
    </header>
  )
}
