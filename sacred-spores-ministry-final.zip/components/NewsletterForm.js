export default function NewsletterForm() {
  return (
    <form onSubmit={(e)=>{ e.preventDefault(); alert('Newsletter signup placeholder — integrate Mailchimp later.'); }} className="flex flex-col gap-3">
      <label className="text-sm font-medium">Join the Mycelial Circle</label>
      <input type="email" placeholder="you@domain.org" className="rounded-lg border px-3 py-2" />
      <div className="flex gap-3">
        <button type="submit" className="px-4 py-2 rounded-full bg-ssGreen text-white">Join</button>
        <button type="button" className="px-4 py-2 rounded-full border">Learn More</button>
      </div>
    </form>
  )
}
