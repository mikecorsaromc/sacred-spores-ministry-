/** Next config placeholder **/
module.exports = { reactStrictMode: true };